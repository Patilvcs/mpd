package com.example.rss;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.MenuItemCompat;

import android.util.Log;
import android.view.MenuInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
//import android.support.v7.widget.SearchView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import android.app.SearchManager;
import android.widget.SearchView;
import android.widget.SearchView.OnQueryTextListener;

public class Activity2 extends AppCompatActivity {

    private static final String TAG ="MainActivity" ;
    ListView scRss;
    //The data will be extracted into the ArrayList
    ArrayList<String> titles;
    ArrayList<String> descriptions;
    ArrayList<String> links;
    ArrayList<String> georss;
    ArrayList<String> authors;
    ArrayList<String> comments;
    ArrayList<String> pubDates;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG,"onCreate: Started.");
        scRss = (ListView) findViewById(R.id.scRss);




        titles = new ArrayList<String>();
        descriptions = new ArrayList<String>();
        links = new ArrayList<String>();
        georss = new ArrayList<String>();
        authors = new ArrayList<String>();
        comments = new ArrayList<String>();
        pubDates = new ArrayList<String>();

        scRss.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //using an intent to open the web page when the user clicks an item in the list
                Uri toLink = Uri.parse(links.get(position));
                Intent intent = new Intent(Intent.ACTION_VIEW, toLink);
                startActivity(intent);

            }
        });
        new Background().execute();

    }
//Call an open connection on the url object that will return an instance that represents a connection to the remote object reffered to the url
//the Inputstream returns a stream that reads from the open connection
    public InputStream getInputStream (URL url){
        try {
            return url.openConnection().getInputStream();
        } catch (IOException e) {
            return null;
        }
    }
//AsyncTask class is used to read from that document
    public class Background extends AsyncTask<Integer, Integer, Exception>
    {
        ProgressDialog progressDialog = new ProgressDialog(Activity2.this);

        Exception exception = null;

        //before we go Background
        //set up a progress dialog
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading feed...");
            progressDialog.show();
        }


        //in the Background
        //We want to catch exceptions
        @Override
        protected Exception doInBackground(Integer... integers) {

            try{
                //set up url object
                URL url = new URL("https://trafficscotland.org/rss/feeds/roadworks.aspx");
                //we create a new instance of pullparser factory that can be used to create xml pullparses that will help us to retrieve data from the xml document
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                //specifies that the deposit produced by the factory will not support xml name spaces
                factory.setNamespaceAware(false);

                //create a new pullparser
                XmlPullParser xpp = factory.newPullParser();

                // UTF_8 - specific input that we reading ( the encode of the document )
                xpp.setInput(getInputStream(url),"UTF_8");

                // the inItem boolean variable will tell us if we are inside the item tags or not
                boolean inItem = false;

                //return the type of the current event, START_TAG, END_TAG, etc.
                int eventType = xpp.getEventType();

                //looping until we reach the end of the document
                while(eventType != XmlPullParser.END_DOCUMENT) {
                    //if it is a START_TAG we need to know the specific type of START_TAG
                    if (eventType == XmlPullParser.START_TAG) {
                        //it will loop and find the first item
                        if (xpp.getName().equalsIgnoreCase("item")) {
                            //we set it true when we are inside the tag
                            inItem = true;
                        } else if (xpp.getName().equalsIgnoreCase("title")) {
                            //checking if we are still inside the item before extracting the title
                            if (inItem) {
                                //if in the title tag and if the title tag is inside the item tag, add the string object to the array. The nextText is the text inside the title tags
                                titles.add(xpp.nextText());
                            }
                        } else if (xpp.getName().equalsIgnoreCase("description")) {
                            if (inItem) {
                                descriptions.add(xpp.nextText());
                            }
                        }
                            else if(xpp.getName().equalsIgnoreCase("link")){
                            if(inItem){
                                links.add(xpp.nextText());
                            }
                        }
                            else if(xpp.getName().equalsIgnoreCase("georss")){
                            if(inItem){
                                georss.add(xpp.nextText());
                            }
                        }
                            else if(xpp.getName().equalsIgnoreCase("author")){
                            if(inItem){
                                authors.add(xpp.nextText());
                            }
                        }
                            else if(xpp.getName().equalsIgnoreCase("comments")){
                            if(inItem){
                                comments.add(xpp.nextText());
                            }
                        }
                        else if(xpp.getName().equalsIgnoreCase("pubDate")){
                            if(inItem){
                                pubDates.add(xpp.nextText());
                            }
                        }
                    }

                    //if is an end tag and if is an item tag , set inside item to false
                    else if(eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item")){
                        inItem = false;
                    }

                    //will increment and go to the next tag
                    eventType = xpp.next();

                }
            }
            catch(MalformedURLException e)
            {
                exception = e;
            }
            //try to extract data and throw an exception
            catch(XmlPullParserException e)
            {
                exception = e;
            }

            catch(IOException e)
            {
                exception = e;
            }


            return exception;
        }

        //after the Background
        @Override
        protected void onPostExecute(Exception s) {
            super.onPostExecute(s);
            //set the data to the list view by using an ArrayAdapter
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity2.this, android.R.layout.simple_list_item_1, titles);
            scRss.setAdapter(adapter);

            // ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, descriptions);
            // scRss.setAdapter(adapter1);
            progressDialog.dismiss();
        }

    }


//search functionality
//    @Override
 //   public boolean onCreateOptionsMenu(Menu menu){
 //       MenuInflater inflater = getMenuInflater();
 //       inflater.inflate(R.menu.menu_search, menu);
//
//        MenuItem searchItem = menu.findItem(R.id.item_search);
//        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
//
//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener(){
//            @Override
//            public boolean onQueryTextChange(String newText){
//                ArrayList<String> templist = new ArrayList<>();
//                for(String temp : titles){
//                    if(temp.toLowerCase().contains(newText.toLowerCase())){
//                        templist.add(temp);
//                    }}
//                ArrayAdapter<String> searchadapter = new ArrayAdapter<String>(Activity2.this, android.R.layout.simple_list_item_1,templist);
//                scRss.setAdapter(searchadapter);
//                return true;//           }

    //            @Override
    //           public boolean onQueryTextSubmit(String query){
    //               return false;
    //           }


    //      });
    //      return super.onCreateOptionsMenu(menu);
    //   }

}